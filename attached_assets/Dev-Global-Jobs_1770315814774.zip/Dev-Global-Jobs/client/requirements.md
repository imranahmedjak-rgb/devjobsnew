## Packages
date-fns | Formatting relative time (e.g. "2 days ago")
framer-motion | Smooth animations for list entry and interactions

## Notes
API endpoints are defined in shared/routes.ts
Images are dynamic from external APIs, no local assets needed
